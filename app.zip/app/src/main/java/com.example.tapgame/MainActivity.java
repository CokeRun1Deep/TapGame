package com.example.tapgame;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private int gems = 0;
    private TextView gemCounter;
    private FirebaseAnalytics mFirebaseAnalytics;
    private FirebaseRemoteConfig mFirebaseRemoteConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        gemCounter = findViewById(R.id.gemCounter);
        Button tapButton = findViewById(R.id.tapButton);
        Button offerButton = findViewById(R.id.offerButton);
        
        tapButton.setOnClickListener(v -> {
            gems++;
            gemCounter.setText("Gems: " + gems);
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.ITEM_ID, "tap");
            mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
        });
        
        offerButton.setOnClickListener(v -> showOffers());
        loadRemoteConfig();
    }
    
    private void loadRemoteConfig() {
        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        mFirebaseRemoteConfig.fetchAndActivate();
    }
    
    private void showOffers() {
        String offersJson = mFirebaseRemoteConfig.getString("offerwall_offers");
        try {
            JSONArray offers = new JSONArray(offersJson);
            for (int i = 0; i < offers.length(); i++) {
                JSONObject offer = offers.getJSONObject(i);
                String url = offer.getString("url");
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                break; // Open first offer for simplicity
            }
        } catch (Exception e) {
            // Fallback to HelloMillions
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.hellomillions.com/lp/raf?r=562ab765%2F975247268")));
        }
    }
}